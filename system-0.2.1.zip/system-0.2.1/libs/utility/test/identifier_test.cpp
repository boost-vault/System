//  identifier_test.cpp  -----------------------------------------------------//

//  Copyright Beman Dawes 2006

//  Distributed under the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

//  See documentation at http://www.boost.org/libs/utility

//----------------------------------------------------------------------------// 

#include <boost/test/minimal.hpp>
#include <boost/identifier.hpp>
#include <iostream>
#include <sstream>

class id_a_type : public boost::identifier<int, id_a_type>
{
public: // note: gcc 3.4.4 requires boost:: and <int, id_a_type>, but other
        // compilers don't. 
  id_a_type()                           : boost::identifier<int, id_a_type>(0){}
  explicit id_a_type( value_type v )    : boost::identifier<int, id_a_type>(v){}
  id_a_type & operator=( value_type v ) { value(v); return *this; }
};

class id_b_type : public boost::identifier<int, id_b_type>
{
public:
  id_b_type()                           : boost::identifier<int, id_b_type>(0){}
  explicit id_b_type( value_type v )    : boost::identifier<int, id_b_type>(v){}
  id_b_type & operator=( value_type v ) { value(v); return *this; }
};

class id_c_type : public boost::identifier<int, id_c_type> {};

class string_id_type : public boost::identifier<std::string, string_id_type>
{
public:
  string_id_type()                           : boost::identifier<std::string, string_id_type>(){}
  explicit string_id_type( value_type v )    : boost::identifier<std::string, string_id_type>(v){}
  string_id_type & operator=( value_type v ) { value(v); return *this; }
};

//----------------------------------------------------------------------------//

int test_main( int, char ** )
{
  id_a_type a0;
  id_a_type a1( 12345 );
  id_a_type a2( 12346 );
  id_a_type a3( a1 );
  id_b_type b1;
  id_c_type c;

//  b1 = a1;  // must be compile error
//  if ( b1 == a1 ) {} // must be compile error

  BOOST_CHECK( a0.value() == 0 );
  BOOST_CHECK( !a0 );
  BOOST_CHECK( !(a0) );
  BOOST_CHECK( a1.value() == 12345 );
  BOOST_CHECK( a1 );
  BOOST_CHECK( !!a1 );
  BOOST_CHECK( a0.value() != a1.value() );
  BOOST_CHECK( a0 != a1 );
  BOOST_CHECK( a0 < a1 );
  BOOST_CHECK( a0 <= a1 );
  BOOST_CHECK( a1 > a0 );
  BOOST_CHECK( a1 >= a0 );
  BOOST_CHECK( a2.value() == 12346 );
  BOOST_CHECK( a2.value() != a1.value() );
  BOOST_CHECK( a2 != a1 );
  a2 = a1;
  BOOST_CHECK( a2.value() == 12345 );
  BOOST_CHECK( a2.value() == a1.value() );
  BOOST_CHECK( a2 == a1 );
  BOOST_CHECK( !(a2 < a1) );
  BOOST_CHECK( a2 <= a1 );
  BOOST_CHECK( !(a2 > a1) );
  BOOST_CHECK( a2 >= a1 );
  BOOST_CHECK( a3.value() == a1.value() );
  BOOST_CHECK( a3 == a1 );

  c.value( 23456 );
  BOOST_CHECK( c.value() == 23456 );

  string_id_type str_id( "foo" );
  BOOST_CHECK( str_id.value() == "foo" );
  BOOST_CHECK( str_id.value() != "bar" );
  BOOST_CHECK( str_id == string_id_type( "foo" ) );
  BOOST_CHECK( str_id != string_id_type( "bar" ) );
  BOOST_CHECK( str_id );
  BOOST_CHECK( !!str_id );

  std::cout << a1.value() << '\n';
  std::cout << a1 << '\n';

  // TODO: why is this failing to compile? enable_if seems to be failing
  // for stringstreams (but not iostreams).
  //std::stringstream ss;
  //ss << a1;
  //BOOST_CHECK( a0.value() != 12345 );
  //ss >> a0;
  //BOOST_CHECK( a0.value() == 12345 );

  return 0;
}

