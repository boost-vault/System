//  boost cpu_timer.hpp  -----------------------------------------------------//

//  Copyright Beman Dawes 1994-2006

//  Distributed under the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org/libs/system for documentation.

//----------------------------------------------------------------------------//

// define BOOST_SYSTEM_SOURCE so that <boost/system/config.hpp> knows
// the library is being built (possibly exporting rather than importing code)
#define BOOST_SYSTEM_SOURCE 

#include <boost/system/cpu_timer.hpp>
#include <boost/io/ios_state.hpp>
#include <cstring>
#include <cassert>

# if defined(BOOST_WINDOWS_API)
#   include <windows.h>
# elif defined(BOOST_POSIX_API)
#   include <sys/times.h>
# else
# error unknown API
# endif

using boost::system::microseconds_t;
using boost::system::duration_t;

namespace
{

# if defined(BOOST_POSIX_API)
  long tick_factor()        // multiplier to convert ticks
                             //  to microseconds; -1 if unknown
  {
    static long tick_factor = 0;
    if ( !tick_factor )
    {
      if ( (tick_factor = ::sysconf( _SC_CLK_TCK )) <= 0 )
        tick_factor = -1;
      else
      {
        assert( tick_factor <= 1000000L ); // doesn't handle large ticks
        tick_factor = 1000000L / tick_factor;  // compute factor
        if ( !tick_factor ) tick_factor = -1;
      }
    }
    return tick_factor;
  }
# endif

  void get_process_times( duration_t & wall,
                          duration_t & user,
                          duration_t & system )
  {
# if defined(BOOST_WINDOWS_API)
    ::GetSystemTimeAsFileTime( (LPFILETIME)&wall );
    FILETIME creation, exit;
    if ( ::GetProcessTimes( ::GetCurrentProcess(), &creation, &exit,
                              (LPFILETIME)&system, (LPFILETIME)&user ) )
    {
      wall   /= 10;  // Windows uses 100 nanosecond ticks
      user   /= 10;
      system /= 10;
    }
    else
    {
      wall = system = user = -1;
    }
# else
    tms tm;
    clock_t c = ::times( &tm );
    if ( c == -1 ) // error
    {
      wall = system = user = microseconds_t(-1);
    }
    else
    {
      wall = microseconds_t(c);
      system = microseconds_t(tm.tms_stime + tm.tms_cstime);
      user = microseconds_t(tm.tms_utime + tm.tms_cutime);
      if ( tick_factor() != -1 )
      {
        wall *= tick_factor();
        user *= tick_factor();
        system *= tick_factor();
      }
      else { wall = user = system = microseconds_t(-1); }
    }
#  endif
  }

void show_time( const char * format, int places, std::ostream & os,
    duration_t wall, duration_t user, duration_t system )
  //  NOTE WELL: Will truncate least-significant digits to LDBL_DIG, which may
  //  be as low as 10, although will be 15 for many common platforms.
  {
    if ( wall < microseconds_t(0) ) return;
    if ( places > 6 ) places = 6;
    else if ( places < 0 ) places = 0;

    boost::io::ios_flags_saver ifs( os );
    boost::io::ios_precision_saver ips( os );
    os.setf( std::ios_base::fixed, std::ios_base::floatfield );
    os.precision( places );

    const long double sec = 1000000.0L;
    duration_t total = system + user;

    for ( ; *format; ++format )
    {
      if ( *format != '%' || !*(format+1) || !std::strchr("wustp", *(format+1)) )
        os << *format;
      else
      {
        ++format;
        switch ( *format )
        {
        case 'w':
          os << wall ;// sec;
          break;
        case 'u':
          os << user ;// sec;
          break;
        case 's':
          os << system ;// sec;
          break;
        case 't':
          os << total ;// sec;
          break;
        case 'p':
          os.precision( 1 );
          //JKG TODO
//           if ( wall && total )
//             os << static_cast<long double>(total) / wall * 100.0;
//           else
//             os << 0.0;
//           os.precision( places );
          break;
        default:
          assert(0);
        }
      }
    }
  }

}  // unnamed namespace

namespace boost
{
  namespace system
  {
    //  cpu_timer  -----------------------------------------------------------//

    void cpu_timer::start()
    {
      get_process_times( m_wall, m_user, m_system );
      m_stopped = false;
    }

    void cpu_timer::stop()
    {
      if ( m_stopped || m_wall == microseconds_t(-1) ) return;
      m_stopped = true;
      
      microseconds_t wall(0), system(0), user(0);
      get_process_times( wall, user, system );
      if ( wall == microseconds_t(-1) ) return;
      m_wall = (wall - m_wall);
      m_user = (user - m_user);
      m_system = (system - m_system);
    }

    void cpu_timer::elapsed( microseconds_t & wall,
                             microseconds_t & user, 
                             microseconds_t & system )
    {
      if ( m_stopped )
      {
        //JKG TODO: this is ugly
        wall = microseconds_t(m_wall.total_microseconds());
        user = microseconds_t(m_user.total_microseconds());
        system = microseconds_t(m_system.total_microseconds());
      }
      else
      {
        get_process_times( wall, user, system );
        if ( wall == microseconds_t(-1) ) return;
        wall -= m_wall;
        user -= m_user;
        system -= m_system;
      }
    }

    //  time_reporter  -------------------------------------------------------//

    void cpu_time_reporter::report()
    {
    //  A) Throwing an exception from a destructor is a Bad Thing,
    //     and report() will often be called from destructors
    //  B) The destructor does output, and that may throw.
    //  C) A cpu_time_reporter is usually not critical to the application.
    //  Therefore, wrap the I/O in a try block, catch and ignore all exceptions.
      try
      {
        show_time( m_format.empty() 
            ? "\nwall %w s, user %u s, system %s s, total cpu %t s, %p%\n"
            : m_format.c_str(),
          m_places, m_os, this->wall(), this->user(), this->system() );
      }

      catch (...) {} // eat any exceptions
    }

  } // namespace system
} // namespace boost
