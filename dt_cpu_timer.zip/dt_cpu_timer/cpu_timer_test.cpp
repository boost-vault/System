//  boost cpu_timer_test.cpp  ------------------------------------------------//

//  Copyright Beman Dawes 2006

//  Distributed under the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org/libs/system for documentation.

#include <boost/system/cpu_timer.hpp>
#include <cstdlib> // for atol()
#include <locale>

using boost::system::microseconds_t;

int main( int argc, char * argv[] )
{
  std::locale loc( "" );
  std::cout.imbue( loc );
  
  boost::system::cpu_time_reporter timer(6);
  boost::system::cpu_time_reporter timer2("\nwall %w s, utilization %p%\n");
  boost::system::cpu_time_reporter timer3(
    "\nwall %w s, total cpu %t s, utilization %p%\n", 3);

  long count = 0;
  microseconds_t wall(0), user(0), system(0);
  microseconds_t timeout = microseconds_t(5000000); // default .5 seconds

  if ( argc > 1 ) timeout = microseconds_t(std::atol( argv[1] ));

  while ( wall < timeout )
  {
    //  The point of this code is to burn both kernal and user cpu time,
    //  with the total less than wall clock time.
    ++count;
    timer.elapsed( wall, user, system );
    //    sleep(1);
    std::cout << "iteration " << count << ", " << wall
      << " wall, " << user << " user, " << system << " system microsecs"
      << std::endl;
  }

  std::cout << count << " iterations\n";
  return 0;
}

