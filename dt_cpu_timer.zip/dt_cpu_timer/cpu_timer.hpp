//  boost cpu_timer.hpp  -----------------------------------------------------//

//  Copyright Beman Dawes 1994-2006

//  Distributed under the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org/libs/system for documentation.

#ifndef BOOST_CPU_TIMER_HPP                  
#define BOOST_CPU_TIMER_HPP

#include <boost/system/config.hpp>
#include <iostream>  // for ostream, cout
#include <string>

#include <boost/date_time/posix_time/posix_time.hpp>

#include <boost/config/abi_prefix.hpp> // must be the last #include

namespace boost
{
  namespace system
  {

    typedef boost::posix_time::microseconds microseconds_t;
    typedef boost::posix_time::time_duration duration_t;
    //    typedef boost::int_64 microseconds_t;
    //    typedef boost::int_64 duration_type;

    //  cpu_timer  -----------------------------------------------------------//

    class BOOST_SYSTEM_DECL cpu_timer
    {
    public:
      cpu_timer() :
        m_error(false),
        m_stopped(true)
      { 
        start(); 
      }

      void            start();
      void            stop();
      bool            stopped() const { return m_stopped; }

      duration_t  wall()     { if ( !m_stopped ) stop(); return m_wall; }
      duration_t  user()     { if ( !m_stopped ) stop(); return m_user; }
      duration_t  system()   { if ( !m_stopped ) stop(); return m_system; }

      void            elapsed( microseconds_t & wall,
                               microseconds_t & user,
                               microseconds_t & system );  // does not stop
    private:
      duration_t       m_wall;
      duration_t       m_user;
      duration_t       m_system;
      bool             m_stopped;
      bool             m_error;
    };

    //  cpu_time_reporter  ---------------------------------------------------//

    class BOOST_SYSTEM_DECL cpu_time_reporter : public cpu_timer
    {
    public:
      explicit cpu_time_reporter( int places = 2, std::ostream & os = std::cout )
         : m_places(places), m_os(os) {}

      explicit cpu_time_reporter( const char * format, int places = 2,
        std::ostream & os = std::cout )
         : m_places(places), m_os(os), m_format(format) {}

      explicit cpu_time_reporter( const std::string & format, int places = 2,
        std::ostream & os = std::cout )
         : m_places(places), m_os(os), m_format(format) {}

     ~cpu_time_reporter() { if ( !stopped() ) report(); }

      void report();

    private:
      int             m_places;
      std::ostream &  m_os;
      std::string     m_format;
    };

  } // namespace system
} // namespace boost

#include <boost/config/abi_suffix.hpp> // pops abi_prefix.hpp pragmas

#endif  // BOOST_CPU_TIMER_HPP
